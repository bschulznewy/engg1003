#include <stdio.h>
int main() {
	char x = 127;
	printf("%d\n", x);
	x++;
	printf("%d\n", x);
	return 0;
}

