#include <stdio.h>

int main() {
printf("%d\n", 9/10);
printf("%f\n", 9/10);
printf("%f\n", 9.0/10);
printf("%f\n", 9/10.0);
printf("%f\n", (float)9/10);
return 0;
}
